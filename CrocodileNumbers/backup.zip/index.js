// index.js


async function init() {
const crocodileFace = `
>=<`;

document.body.innerHTML = `<pre>${crocodileFace}</pre>`;

}

init();